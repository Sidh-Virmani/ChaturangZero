# How to push this folder and show the team

This is the **full ChaturangZero project** (Sidh’s `main` plus Anji’s UI/UX). `shared/game_core/` is still empty. Pieces use a **mock** adapter until the rules engine exists.

Do **not** zip `shared/ui/node_modules` or `.git`. Run `npm install` on each machine.

---

## Message you can send Sidh / the team

Copy and paste:

```text
I have a UI/UX update for ChaturangZero (play board only — still mock moves, no game_core yet).

Please:
1. Download ChaturangZero-full.zip (or take the folder I shared).
2. Unzip. If you already have the GitHub repo, copy the unzipped files ON TOP of your clone (keep your .git).
3. Create a branch and push so everyone can see it:

   git switch main
   git pull --ff-only
   git checkout -b cursor/ui-ux-anji
   git add -A
   git commit -m "Polish ChaturangZero play board UX (mock adapter still)."
   git push -u origin cursor/ui-ux-anji

4. Open a PR into main on https://github.com/Sidh-Virmani/ChaturangZero

To try it locally (Node.js 20+):
- Windows: double-click start-chaturangzero.bat
- Mac/Linux: chmod +x start-chaturangzero.sh && ./start-chaturangzero.sh

Then open http://127.0.0.1:43147/

Expect: SVG pieces, flip board, light/dark, sound, captures tray, drag + click.
Only a few demo moves work (padati/ashva) until game_core is written.
```

---

## If you already cloned GitHub

From the unzipped folder, copy everything except `.git` into the clone, then branch + push as above.

```bash
# example: overlay this zip onto your clone
rsync -a --exclude node_modules --exclude .git /path/to/unzipped/ChaturangZero/ /path/to/ChaturangZero/
cd /path/to/ChaturangZero
git checkout -b cursor/ui-ux-anji
git add -A
git status   # should show shared/ui + TEAM_PUSH.md + start scripts
git commit -m "Polish ChaturangZero play board UX (mock adapter still)."
git push -u origin cursor/ui-ux-anji
```

---

## What they should see

Header: **Mock** badge, Flip, Light/Dark, Sound.  
Board: named Chaturanga pieces (Raja, Mantri, Ratha, Gaja, Ashva, Padati).  
Sidebar: turn, New game, captured pieces, move history, piece legend.  
Yellow banner: only scripted demo replies until `game_core`.
