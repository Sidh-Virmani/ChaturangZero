# ChaturangZero

AlphaZero-style **Chaturanga** engine. This snapshot is Sidh Virmani’s `main` (GitHub zip commit `0c709c43`), imported here because the GitHub repo is private.

## What is in this snapshot

- **`shared/ui/`** — Vite + React + TypeScript play board (mock adapter, not real rules).
- **`shared/game_core/`** — empty. The UI cannot play a real game until this exists.
- **`p1_representation/` … `p4_training/`** — empty AI modules (placeholders).
- **`Architecture_plan.md`** — team plan and module APIs.

## Run the UI

Needs Node.js 20+ and npm.

**Linux / macOS** (from the project root):

```bash
chmod +x start-chaturangzero.sh
./start-chaturangzero.sh
```

Then open [http://127.0.0.1:43147/](http://127.0.0.1:43147/).

**Windows:**

```bat
start-chaturangzero.bat
```

Then open [http://127.0.0.1:43147/](http://127.0.0.1:43147/).

To share this folder with the GitHub repo, see `TEAM_PUSH.md`.

Override host/port on Unix:

```bash
CHATURANGZERO_HOST=0.0.0.0 CHATURANGZERO_PORT=43147 ./start-chaturangzero.sh
```

## Why pieces feel “weird”

The React app talks only to `MockGameAdapter`. That adapter hard-codes a handful of pawn/knight-like replies. It is **not** Chaturanga legality. Real moves belong in `shared/game_core/` and should reach the UI through the `GameAdapter` interface.

## First milestone (from the architecture plan)

Two humans can play a complete legal Chaturanga game through this UI, with every move coming from the game core.
